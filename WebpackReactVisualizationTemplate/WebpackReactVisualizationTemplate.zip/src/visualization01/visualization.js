//
// TODO: Add import statements for chosen React chart library
//
import x from '<chart library>';
import React from 'react';
import ReactDOM from 'react-dom';
//
//    Entry function declaration
//
export function visualization(config) {
 
  var data = config.data;
  var style = config.style;
  var width = parseFloat(config.width);
  var height = parseFloat(config.height);
 
  //console.log(JSON.stringify(config));
  //
  // TODO: Add chart code here
  //
  }

